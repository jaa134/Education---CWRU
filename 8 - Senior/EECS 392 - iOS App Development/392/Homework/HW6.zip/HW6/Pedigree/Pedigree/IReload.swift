//
//  IReload.swift
//  Pedigree
//
//  Created by Jacob Alspaw on 3/18/19.
//  Copyright © 2019 Jacob Alspaw. All rights reserved.
//

import Foundation

protocol IReload {
    func reload()
}
