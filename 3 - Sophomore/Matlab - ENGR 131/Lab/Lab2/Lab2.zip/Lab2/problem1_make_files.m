% Jacob Alspaw
% jaa134

months = [4 5 6 7 8 9];
save months.txt months -ascii
temps = [63.3 68.1 74.6 78.2 82.3 72.5];
save temps.txt temps -ascii
clear
