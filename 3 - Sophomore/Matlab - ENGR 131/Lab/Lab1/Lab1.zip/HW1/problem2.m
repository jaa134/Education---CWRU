%Jacob Alspaw
a = 3;
b = 4;
c = 1;
x1 = (-b + sqrt(b ^ 2 - 4 * a * c)) / (2 * a)
x2 = (-b - sqrt(b ^ 2 - 4 * a * c)) / (2 * a) 