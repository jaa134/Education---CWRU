%Jacob Alspaw
a = 3;
b = 4;
c = sqrt(a * a + b * b)